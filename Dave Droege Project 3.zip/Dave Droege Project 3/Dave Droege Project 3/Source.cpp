// Dave Droege
// December 15 2024

#include "CG_Functions.h"
#include <set>
#include <iostream>
#include <fstream>
#include <string>

int main() {

	// Define the variable that will store the user's input
	string userInput;

	// Define the variable that will be used to call the CG_Functions Class
	CG_Functions produceFunction;

	// Use the DataStorage function to store the data
	produceFunction.DataStorage();

	// Use a while loop to keep the program running until the user inputs "4" to Exit the program
	while (userInput != "4") {

		// Use the DisplayMenu command to display the menu to the user
		produceFunction.DisplayMenu();

		// Collect the user's input
		cin >> userInput;

		// use if else statements to check the users input and output their selection
		if (userInput == "1") {

			// Prompt the user to input hte produce they would like search for
			cout << "Please enter the produce you would like to search for: ";
			cin >> userInput; // Collect the user's input

			// Use the Produce Frequency function to find the value of the frequency and display it to the user
			cout << userInput << ": " << produceFunction.ProduceFrequency(userInput) << endl;
		}

		else if (userInput == "2") {

			// Use the ListProduce Function to display the produce with their corresponding frequencies to the user
			produceFunction.ListProduce();
		}

		else if (userInput == "3") {

			// Use the ListHistogram function to display the produce with their corresponding frequencies as a histogram
			produceFunction.ListHistogram();
		}
	}
}