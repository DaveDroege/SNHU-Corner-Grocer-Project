// Dave Droege
// December 15 2024

#include "CG_Functions.h"
#include <iostream>
#include <fstream>
#include <string>
#include <set>
using namespace std;


// Define a function that Displays the menu that the user will use to navigate the program
void CG_Functions::DisplayMenu() {
	cout << endl;
	cout << "--------------------------------------------------------" << endl;
	cout << "Please select one of the following options." << endl;
	cout << "--------------------------------------------------------" << endl;
	cout << "1 - Search for a specific produce item" << endl;
	cout << "2 - Print the produce list with corresponding frequencies" << endl;
	cout << "3 - Print the produce frequencies as a histogram" << endl;
	cout << "4 - Exit the program" << endl;
	cout << endl;
}


// Define a function that will scan through the text file and find the number of times a specific produce occurs
int CG_Functions::ProduceFrequency(string userInput) {

	// Define the variables that will be needed to run the function
	ifstream produceIFS;
	string currentProduce;
	int frequency = 0;

	// Use the produceIFS variable to open the inventory.txt file
	produceIFS.open("inventory.txt");

	// Verify the file opened
	if (!produceIFS.is_open()) {
		cout << "ERROR: File did not open properly" << endl;
	}

	// Using a while loop find the frequency of the userInput
	while (produceIFS >> currentProduce) {
		if (currentProduce == userInput) {
			frequency += 1;
		}
	}

	// Close the .txt file
	produceIFS.close();

	return frequency;
}


// Define the function that will list the produce with their corresponding frequencies
void CG_Functions::ListProduce() {
	
	// Define the necessary variables to run the function
	ifstream produceIFS;
	string currentProduce;
	set<string> produceList;

	// open the text file
	produceIFS.open("inventory.txt");

	// Verify the file opened
	if (!produceIFS.is_open()) {
		cout << "ERROR: File did not open properly" << endl;
	}

	// Use a while loop to scan through the text file and form a list of the individual produces and their frequencies
	while (produceIFS >> currentProduce) {
		produceList.insert(currentProduce);
	}

	// Close the .txt file
	produceIFS.close();

	// Use a for loop to iterate through the set and print the produces and their frequencies
	cout << "Produce:" << endl;
	for (const string& produce : produceList) {
		cout << produce << " " << ProduceFrequency(produce) << endl;
	}

	return;
}


// Define the function that will be used to create the histogram bars
string CG_Functions::CharString(size_t n, char c) {
	
	// Define the string
	string charString;

	// Use append to create the custom string
	charString.append(n, c);

	// Return the string
	return charString;
}



// Define the function that will list the produces as a histogram
void CG_Functions::ListHistogram() {

	// Define the necessary variables to run the function
	ifstream produceIFS;
	string currentProduce;
	set<string> histogramList;

	// open the text file
	produceIFS.open("inventory.txt");

	// Verify the file opened
	if (!produceIFS.is_open()) {
		cout << "ERROR: File did not open properly" << endl;
	}

	// Use a while loop to scan through the text file and form a list of the individual produces and their frequencies
	while (produceIFS >> currentProduce) {
		histogramList.insert(currentProduce);
	}

	// Close the .txt file
	produceIFS.close();

	// Use a for loop to iterate through the set to print the histogram
	cout << "Produce:" << endl;
	for (const string& produce : histogramList) {
		cout << produce << " " << CharString(ProduceFrequency(produce), '=') << endl;
	}

	return;
}


// Define the function that will be used to store the data of the produce

void CG_Functions::DataStorage() {

	// Define the necessary variables to run the function
	ifstream produceIFS;
	ofstream produceOFS;
	string currentProduce;
	set<string> produceList;

	// open the text file
	produceIFS.open("inventory.txt");

	// open the data file
	produceOFS.open("frequency.dat");

	// Verify the files opened
	if (!produceIFS.is_open()) {
		cout << "ERROR: .TXT File did not open properly" << endl;
	}

	if (!produceOFS.is_open()) {
		cout << "ERROR: Data File did not open properly" << endl;
	}

	// Use a while loop to scan through the text file and form a list of the individual produces and their frequencies
	while (produceIFS >> currentProduce) {
		produceList.insert(currentProduce);
	}

	// Close the .txt file
	produceIFS.close();

	// Use a for loop to iterate through the set and store the values in the data file
	cout << "Produce:" << endl;
	for (const string& produce : produceList) {
		produceOFS << produce << " " << ProduceFrequency(produce) << endl;
	}

	return;
}