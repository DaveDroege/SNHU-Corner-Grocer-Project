// Dave Droege
// December 15 2024

#pragma once
#include <iostream>
#include <string>
#include <set>
using namespace std;
#ifndef CG_FUNCTIONS_H
#define CG_FUNCTIONS_H
using namespace std;


class CG_Functions
{
public:
	void DisplayMenu();
	int ProduceFrequency(string userInput);
	void ListProduce();
	string CharString(size_t n, char c);
	void ListHistogram();
	void DataStorage();

private:
	string currentProduce;
};

#endif // !CG_FUNCTIONS_H